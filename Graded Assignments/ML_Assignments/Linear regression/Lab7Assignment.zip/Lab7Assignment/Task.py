import numpy as np
import matplotlib.pyplot as plt
import os
import pandas as pd

# Generate datasets based on given equations
def generate_data1(a, b, n):
    X = np.random.uniform(low=0, high=5, size=n)
    noise = np.random.normal(0, 2, size=n)
    Y = a * X + b + noise
    return X, Y

def generate_data2(a, b, c, n):
    X = np.random.uniform(low=0, high=5, size=n)
    noise = np.random.normal(0, 2, size=n)
    Y = a * X**2 + b * X + c + noise
    return X, Y

def generate_data3(n):
    X = np.random.uniform(low=0, high=5, size=n)
    noise = np.random.normal(0, 2, size=n)
    Y = np.exp(X) + noise
    return X, Y

# Design matrix for linear regression
def design_matrix(X, d):
    return np.vander(X, d + 1, increasing=True)

# Linear regression using the closed-form solution (Normal Equation)
def linear_regression(X, Y, d):
    Phi = design_matrix(X, d)
    w = np.linalg.inv(Phi.T @ Phi) @ Phi.T @ Y
    return w

# Least squares error function
def least_squares_error(X, Y, w, d):
    Phi = design_matrix(X, d)
    Y_pred = Phi @ w
    return np.mean((Y - Y_pred) ** 2)

# Save plot as a .jpg file in the same folder as the script
def save_plot_as_image(X_train, Y_train, X_test, Y_test, w, d, title):
    # Get the current working directory (same folder as script)
    current_folder = os.path.dirname(os.path.realpath(__file__))
    file_path = os.path.join(current_folder, f"{title}.jpg")
    
    # Plot training data
    plt.figure()
    plt.scatter(X_train, Y_train, color='blue', label='Training data')
    X_plot = np.linspace(0, 10, 100)
    Phi_plot = design_matrix(X_plot, d)
    Y_plot = Phi_plot @ w
    plt.plot(X_plot, Y_plot, color='red', label=f'Model (d={d})')
    plt.title(f'{title} - Training Data')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.legend()
    plt.savefig(f"{file_path}_train.jpg", format='jpg')
    plt.close()
    
    # Plot test data
    plt.figure()
    plt.scatter(X_test, Y_test, color='green', label='Test data')
    plt.plot(X_plot, Y_plot, color='red', label=f'Model (d={d})')
    plt.title(f'{title} - Test Data')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.legend()
    plt.savefig(f"{file_path}_test.jpg", format='jpg')
    plt.close()

# Generate datasets
a, b, c = 2, 3, 4
n = 100
X1, Y1 = generate_data1(a, b, n)
X2, Y2 = generate_data2(a, b, c, n)
X3, Y3 = generate_data3(n)


# Split into training and test sets
X1_train, Y1_train = X1[:20], Y1[:20]
X1_test, Y1_test = X1[20:], Y1[20:]
X2_train, Y2_train = X2[:20], Y2[:20]
X2_test, Y2_test = X2[20:], Y2[20:]
X3_train, Y3_train = X3[:20], Y3[:20]
X3_test, Y3_test = X3[20:], Y3[20:]

# 2. Linear Regression with Closed-Form Solution (Normal Equation)
for d in [1, 2, 5, 10]:
    w1 = linear_regression(X1_train, Y1_train, d)
    w2 = linear_regression(X2_train, Y2_train, d)
    w3 = linear_regression(X3_train, Y3_train, d)
    
    # Training and Test Errors
    print(f'D1, d={d}, Training Error: {least_squares_error(X1_train, Y1_train, w1, d)}')
    print(f'D1, d={d}, Test Error: {least_squares_error(X1_test, Y1_test, w1, d)}')
    save_plot_as_image(X1_train, Y1_train, X1_test, Y1_test, w1, d, f'D1_d_{d}')
    
    print(f'D2, d={d}, Training Error: {least_squares_error(X2_train, Y2_train, w2, d)}')
    print(f'D2, d={d}, Test Error: {least_squares_error(X2_test, Y2_test, w2, d)}')
    save_plot_as_image(X2_train, Y2_train, X2_test, Y2_test, w2, d, f'D2_d_{d}')
    
    print(f'D3, d={d}, Training Error: {least_squares_error(X3_train, Y3_train, w3, d)}')
    print(f'D3, d={d}, Test Error: {least_squares_error(X3_test, Y3_test, w3, d)}')
    save_plot_as_image(X3_train, Y3_train, X3_test, Y3_test, w3, d, f'D3_d_{d}')
    print(w1, "Coefficients for D1")
    print(w2, "Coefficients for D2")
    print(w3, "Coefficients for D3")

# 3. Stochastic Gradient Descent (SGD)
def stochastic_gradient_descent(X, Y, d, learning_rate=0.001, epochs=100000):
    Phi = design_matrix(X, d)
    w = np.random.randn(d + 1)
    n = len(Y)
    
    # Normalize the data (only columns where std > 0)
    means = np.mean(Phi, axis=0)
    stds = np.std(Phi, axis=0)
    Phi = (Phi - means) / np.where(stds == 0, 1, stds)  # Prevent division by zero
    Y = (Y - np.mean(Y)) / np.std(Y)  # Normalize Y as well
    
    for epoch in range(epochs):
        for i in range(n):
            xi = Phi[i, :]
            yi = Y[i]
            gradient = (xi @ w - yi) * xi
            w = w - learning_rate * gradient
            
    return w


# Compare Linear Regression (Closed-Form) and SGD
for d in [1, 2, 5, 10]:
    w1_sgd = stochastic_gradient_descent(X1_train, Y1_train, d)
    w2_sgd = stochastic_gradient_descent(X2_train, Y2_train, d)
    w3_sgd = stochastic_gradient_descent(X3_train, Y3_train, d)
    
    print(f'D1, d={d}, SGD Training Error: {least_squares_error(X1_train, Y1_train, w1_sgd, d)}')
    print(f'D1, d={d}, SGD Test Error: {least_squares_error(X1_test, Y1_test, w1_sgd, d)}')
    save_plot_as_image(X1_train, Y1_train, X1_test, Y1_test, w1_sgd, d, f'D1_SGD_d_{d}')
    
    print(f'D2, d={d}, SGD Training Error: {least_squares_error(X2_train, Y2_train, w2_sgd, d)}')
    print(f'D2, d={d}, SGD Test Error: {least_squares_error(X2_test, Y2_test, w2_sgd, d)}')
    save_plot_as_image(X2_train, Y2_train, X2_test, Y2_test, w2_sgd, d, f'D2_SGD_d_{d}')
    
    print(f'D3, d={d}, SGD Training Error: {least_squares_error(X3_train, Y3_train, w3_sgd, d)}')
    print(f'D3, d={d}, SGD Test Error: {least_squares_error(X3_test, Y3_test, w3_sgd, d)}')
    save_plot_as_image(X3_train, Y3_train, X3_test, Y3_test, w3_sgd, d, f'D3_SGD_d_{d}')
    print(w1_sgd, "Coefficients for D1")
    print(w2_sgd, "Coefficients for D2")
    print(w3_sgd, "Coefficients for D3")

# create function for rigid regularization
def ridge_regression(X, Y, d, lambda_):
    Phi = design_matrix(X, d)
    n, m = Phi.shape
    I = np.eye(m)
    w = np.linalg.inv(Phi.T @ Phi + lambda_ * I) @ Phi.T @ Y
    return w

# Split into training, validation and test sets
X1_train, Y1_train = X1[:20], Y1[:20]
X1_val, Y1_val = X1[20:40], Y1[20:40]
X1_test, Y1_test = X1[40:], Y1[40:]
X2_train, Y2_train = X2[:20], Y2[:20]
X2_val, Y2_val = X2[20:40], Y2[20:40]
X2_test, Y2_test = X2[40:], Y2[40:]
X3_train, Y3_train = X3[:20], Y3[:20]
X3_val, Y3_val = X3[20:40], Y3[20:40]
X3_test, Y3_test = X3[40:], Y3[40:]

# Function to perform cross-validation to choose the best value of λ and d
def cross_validation(X_train, Y_train, X_val, Y_val, lambda_s, degrees):
    best_lambda = None
    best_error = float('inf')
    best_d = None
    for d in degrees:
        for lambda_ in lambda_s:
            w_ridge = ridge_regression(X_train, Y_train, d, lambda_)
            error = least_squares_error(X_val, Y_val, w_ridge, d)
            if error < best_error:
                best_error = error
                best_lambda = lambda_
                best_d = d
    return best_lambda, best_d

lambda_s = np.array([0.01, 0.1, 1, 10, 100])

# Perform cross-validation to choose the best value of λ and d for dataset 1
best_lambda1, best_d1 = cross_validation(X1_train, Y1_train, X1_val, Y1_val, lambda_s, [1, 2, 5, 10])
best_lambda2, best_d2 = cross_validation(X2_train, Y2_train, X2_val, Y2_val, lambda_s, [1, 2, 5, 10])
best_lambda3, best_d3 = cross_validation(X3_train, Y3_train, X3_val, Y3_val, lambda_s, [1, 2, 5, 10])

# Train the model with the best λ and d for all datasets
w1_ridge = ridge_regression(X1_train, Y1_train, best_d1, best_lambda1)
print(f'D1, d={best_d1}, Lambda={best_lambda1}, Training Error: {least_squares_error(X1_train, Y1_train, w1_ridge, best_d1)}')
print(f'D1, d={best_d1}, Lambda={best_lambda1}, Test Error: {least_squares_error(X1_test, Y1_test, w1_ridge, best_d1)}')
save_plot_as_image(X1_train, Y1_train, X1_test, Y1_test, w1_ridge, best_d1, f'D1_Ridge_d_{best_d1}')

w2_ridge = ridge_regression(X2_train, Y2_train, best_d2, best_lambda2)
print(f'D2, d={best_d2}, Lambda={best_lambda2}, Training Error: {least_squares_error(X2_train, Y2_train, w2_ridge, best_d2)}')
print(f'D2, d={best_d2}, Lambda={best_lambda2}, Test Error: {least_squares_error(X2_test, Y2_test, w2_ridge, best_d2)}')
save_plot_as_image(X2_train, Y2_train, X2_test, Y2_test, w2_ridge, best_d2, f'D2_Ridge_d_{best_d2}')

w3_ridge = ridge_regression(X3_train, Y3_train, best_d3, best_lambda3)
print(f'D3, d={best_d3}, Lambda={best_lambda3}, Training Error: {least_squares_error(X3_train, Y3_train, w3_ridge, best_d3)}')
print(f'D3, d={best_d3}, Lambda={best_lambda3}, Test Error: {least_squares_error(X3_test, Y3_test, w3_ridge, best_d3)}')
save_plot_as_image(X3_train, Y3_train, X3_test, Y3_test, w3_ridge, best_d3, f'D3_Ridge_d_{best_d3}')

# Design matrix for multiple features
def design_matrix_multifeature(X, d):
    n, m = X.shape
    Phi = np.ones((n, 1))
    for i in range(1, d + 1):
        Phi = np.hstack((Phi, X ** i))
    return Phi

def ridge_regression_multifeature(X, Y, d, lambda_):
    Phi = design_matrix_multifeature(X, d)
    n, m = Phi.shape
    I = np.eye(m)
    w = np.linalg.inv(Phi.T @ Phi + lambda_ * I) @ Phi.T @ Y
    return w

def least_squares_error_multifeature(X, Y, w, d):
    Phi = design_matrix_multifeature(X, d)  # Use multi-feature version
    Y_pred = Phi @ w
    return np.mean((Y - Y_pred) ** 2)
# Load the datasets
white_wine = pd.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-white.csv', sep=';')
red_wine = pd.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv', sep=';')


# Add a column for the type of wine
white_wine['type'] = 'white'
red_wine['type'] = 'red'

# Combine the datasets
wine = pd.concat([white_wine, red_wine], axis=0)

# Split the data into features and target
X = wine.drop(columns=['quality', 'type']).values
Y = wine['quality'].values

# Split the data into training, validation and test sets
n_train = int(0.6 * len(X))
n_val = int(0.2 * len(X))
X_train, Y_train = X[:n_train], Y[:n_train]
X_val, Y_val = X[n_train:n_train + n_val], Y[n_train:n_train + n_val]
X_test, Y_test = X[n_train + n_val:], Y[n_train + n_val:]

# Standardize the features
def standardize(X_train, X_val, X_test):
    mean = np.mean(X_train, axis=0)
    std = np.std(X_train, axis=0)
    X_train = (X_train - mean) / std
    X_val = (X_val - mean) / std
    X_test = (X_test - mean) / std
    return X_train, X_val, X_test

X_train, X_val, X_test = standardize(X_train, X_val, X_test)

# Perform cross-validation to choose the best value of λ
def cross_validation_wine(X_train, Y_train, X_val, Y_val, lambda_s, degrees):
    best_lambda = None
    best_error = float('inf')
    best_d = None

    for d in degrees:
        for lambda_ in lambda_s:
            w_ridge = ridge_regression_multifeature(X_train, Y_train, d, lambda_)
            error = least_squares_error_multifeature(X_val, Y_val, w_ridge, d)
            if error < best_error:
                best_error = error
                best_lambda = lambda_
                best_d = d

    return best_lambda, best_d

# Perform cross-validation to choose the best value of λ and d for wine dataset
best_lambda, best_d = cross_validation_wine(X_train, Y_train, X_val, Y_val, lambda_s, [1, 2, 5, 10])

# Train the model with the best λ and d
w_ridge = ridge_regression_multifeature(X_train, Y_train, best_d, best_lambda)
print(f'Wine, d={best_d}, Lambda={best_lambda}, Training Error: {least_squares_error_multifeature(X_train, Y_train, w_ridge, best_d)}')
print(f'Wine, d={best_d}, Lambda={best_lambda}, Test Error: {least_squares_error_multifeature(X_test, Y_test, w_ridge, best_d)}')
print(w_ridge, "Coefficients for Wine")



