import numpy as np
import matplotlib.pyplot as plt

mean1 = [0, 0]
cov1 = [[1, 0], [0, 1]]

mean2 = [5, 5]
cov2 = [[1, 0], [0, 1]]

x1 = np.random.multivariate_normal(mean1, cov1, 50)
x2 = np.random.multivariate_normal(mean2, cov2, 50)
y1 = np.zeros(50)
y2 = np.ones(50)
y1 = y1.reshape(-1, 1)
y2 = y2.reshape(-1, 1)
x1 = np.concatenate((x1, y1), axis=1)
x2 = np.concatenate((x2, y2), axis=1)
x = np.concatenate((x1, x2), axis=0)
np.random.shuffle(x)

w_init = np.random.rand(x.shape[1]-1, 1)
b_init = np.random.rand()

def plotting_initial_dicision_curve(x,w,b):
    x1 = np.linspace(-5, 10, 100)
    x2 = (-b - w[0] * x1) / w[1]
    plt.plot(x1, x2, '-r', label='Decision Boundary')
    plt.scatter(x[x[:, 2] == 0][:, 0], x[x[:, 2] == 0][:, 1], label='Class 0')
    plt.scatter(x[x[:, 2] == 1][:, 0], x[x[:, 2] == 1][:, 1], label='Class 1')
    plt.xlabel('x1')
    plt.ylabel('x2')
    plt.title('Scatter plot of x1 and x2')
    plt.legend()
    plt.savefig('initial_decision_curve.png')
    plt.show()

plotting_initial_dicision_curve(x,w_init,b_init)

def signum(x):
    x = x.item()
    return 1 if x >= 0 else 0

def weight_update(y_hat, y, x, w, b, lr):
    w = w + lr * (y - y_hat) * x.reshape(-1, 1)
    b = b + lr * (y - y_hat)
    return w, b
def perceptron(x,w,b,lr,tol = 1e-4,max_iter = 1000):
    J=[]
    for i in range(max_iter):
        J.append(0)
        for j in range(x.shape[0]):
            y_hat = signum(np.dot(x[j, :2], w) + b)
            w, b = weight_update(y_hat, x[j, 2], x[j, :2], w, b, lr)
            J[i] += 0.5 * (x[j, 2] - y_hat) ** 2
        if J[i] < tol:
            break   
    return w,b,J
def predict(w,b,x):
    return signum(np.dot(x, w) + b)

w,b,J = perceptron(x,w_init,b_init,0.0001)

def plotting_final_dicision_curve(x,w,b):
    x1 = np.linspace(-5, 10, 100)
    x2 = (-b - w[0] * x1) / w[1]
    plt.plot(x1, x2, '-r', label='Decision Boundary')
    plt.scatter(x[x[:, 2] == 0][:, 0], x[x[:, 2] == 0][:, 1], label='Class 0')
    plt.scatter(x[x[:, 2] == 1][:, 0], x[x[:, 2] == 1][:, 1], label='Class 1')
    plt.xlim(min(x1.min(), x2.min()), max(x1.max(), x2.max()))
    plt.ylim(min(x2.min(), x1.min()), max(x1.max(), x2.max()))
    plt.xlabel('x1')
    plt.ylabel('x2')
    plt.title('Final decision curve Scatter plot of x1 and x2')
    plt.legend()
    plt.savefig('final_decision_curve.png')
    plt.show()

plotting_final_dicision_curve(x,w,b)

def plotting_cost1(J):
    plt.plot(J)
    plt.xlabel('Iterations')
    plt.ylabel('Cost')
    plt.title('Perceptron Cost vs Iterations')
    plt.savefig('Perceptron_cost_vs_iterations.png')
    plt.show()

plotting_cost1(J)

def batch_perceptron(x, w, b, lr, tol=1e-4, max_iter=1000, batch_size=5):
    J = []
    for i in range(max_iter):
        J.append(0)
        for j in range(0, x.shape[0], batch_size):
            misclassified = []
            for k in range(j, min(j + batch_size, x.shape[0])):
                y_hat = signum(np.dot(x[k, :2], w) + b)
                if y_hat != x[k, 2]:
                    misclassified.append((x[k, :2], x[k, 2]))
            if len(misclassified) > 0:
                grad_w = np.sum([(y_i - signum(np.dot(x_i, w) + b)) * x_i for x_i, y_i in misclassified], axis=0).reshape(-1, 1)
                grad_b = np.sum([(y_i - signum(np.dot(x_i, w) + b)) for x_i, y_i in misclassified])
                w = w + lr * grad_w
                b = b + lr * grad_b
                J[i] += 0.5 * np.sum([(y_i - signum(np.dot(x_i, w) + b)) ** 2 for x_i, y_i in misclassified])
        if J[i] < tol:
            break
    return w, b, J

w,b,J = batch_perceptron(x,w_init,b_init,0.0001)
def plotting_final_dicision_curve_batch_perceptron(x,w,b):
    x1 = np.linspace(-5, 10, 100)
    x2 = (-b - w[0] * x1) / w[1]
    plt.plot(x1, x2, '-r', label='Decision Boundary')
    plt.scatter(x[x[:, 2] == 0][:, 0], x[x[:, 2] == 0][:, 1], label='Class 0')
    plt.scatter(x[x[:, 2] == 1][:, 0], x[x[:, 2] == 1][:, 1], label='Class 1')
    plt.xlim(min(x1.min(), x2.min()), max(x1.max(), x2.max()))
    plt.ylim(min(x2.min(), x1.min()), max(x1.max(), x2.max()))
    plt.xlabel('x1')
    plt.ylabel('x2')
    plt.title('Final decision curve for batch perceptron Scatter plot of x1 and x2')
    plt.legend()
    plt.savefig('batch_perceptron_final_decision_curve.png')
    plt.show()


plotting_final_dicision_curve_batch_perceptron(x,w,b)

def plotting_cost2(J):
    plt.plot(J)
    plt.xlabel('Iterations')
    plt.ylabel('Cost')
    plt.title('Batch perceptron Cost vs Iterations')
    plt.savefig('batch_perceptron_cost_vs_iterations.png')
    plt.show()
plotting_cost2(J)